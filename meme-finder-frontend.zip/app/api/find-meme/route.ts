export async function POST(req: Request) {
  try {
    const { quote, mode } = await req.json()

    if (!quote || typeof quote !== "string" || quote.trim().length === 0) {
      return new Response(JSON.stringify({ error: "Quote is required." }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      })
    }

    const prodUrl = process.env.N8N_FIND_MEME_WEBHOOK_URL || "https://tambi.app.n8n.cloud/webhook/find-meme"
    const testUrl = prodUrl.includes("/webhook-test/") ? prodUrl : prodUrl.replace("/webhook/", "/webhook-test/")

    const preferTest = mode === "test"

    async function attempt(url: string) {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ quote }),
      })
      const text = await res.text().catch(() => "")
      let json: any = null
      try {
        json = text ? JSON.parse(text) : null
      } catch {
        // non-JSON body
      }
      return { res, text, json }
    }

    // Try according to preference, then fallback
    const firstUrl = preferTest ? testUrl : prodUrl
    let { res: n8nRes, text, json } = await attempt(firstUrl)
    let usedUrl = firstUrl

    // If the workflow isn't active, n8n production URL returns 404 "not registered" — try test URL automatically.
    if (!n8nRes.ok && n8nRes.status === 404 && (text.includes("not registered") || text.includes('"code":404'))) {
      const altUrl = firstUrl === prodUrl ? testUrl : prodUrl
      console.log("[v0] First webhook attempt 404; retrying alt URL:", altUrl)
      const retry = await attempt(altUrl)
      n8nRes = retry.res
      text = retry.text
      json = retry.json
      usedUrl = altUrl
    }

    if (!n8nRes.ok) {
      const isUnusedRespondError =
        n8nRes.status === 500 &&
        ((typeof json?.message === "string" && json.message.includes("Unused Respond to Webhook")) ||
          text.includes("Unused Respond to Webhook"))

      // Strengthen hints for both prod and test cases based on latest n8n guidance
      let hint: string | undefined = (json?.hint as string | undefined) || undefined

      if (!hint) {
        if (n8nRes.status === 404) {
          hint = usedUrl.includes("/webhook-test/")
            ? "Click the 'Execute workflow' button in n8n, then submit again. In test mode, the webhook only works once immediately after clicking Execute."
            : "Activate the n8n workflow (top-right toggle) to use the production URL. Production calls won't show on the canvas—check Executions instead."
        } else if (isUnusedRespondError) {
          hint =
            "n8n reports an unused 'Respond to Webhook' node. Ensure exactly one Respond to Webhook node runs on the path triggered by your Webhook, or remove it and set the Webhook node response (e.g., 'On Received' or 'Last Node')."
        }
      }

      console.log(
        "[v0] n8n request failed",
        JSON.stringify({ status: n8nRes.status, usedUrl, message: json?.message || text || null }),
      )

      return new Response(
        JSON.stringify({
          error: "Failed to fetch meme from webhook",
          status: n8nRes.status,
          detail: json?.message || text || null,
          hint,
          n8n_url_used: usedUrl,
          suggested_action: usedUrl.includes("/webhook-test/")
            ? "In n8n, click Execute on the canvas, then immediately try again."
            : "In n8n, activate the workflow to enable production webhook.",
        }),
        { status: 502, headers: { "Content-Type": "application/json" } },
      )
    }

    let data = json ?? (await n8nRes.json().catch(() => null)) ?? {}
    if (Array.isArray(data)) {
      // pick first item when n8n returns an array like: [ { meme_url, title } ]
      data = data[0] ?? {}
    }
    const normalized = typeof data === "object" && data !== null ? data : {}
    return new Response(JSON.stringify(normalized), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    })
  } catch (err: any) {
    return new Response(JSON.stringify({ error: "Unexpected server error", detail: err?.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}
