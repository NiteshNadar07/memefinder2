export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const src = searchParams.get("url")
    const titleParam = searchParams.get("title") || "meme"

    if (!src) {
      return new Response(JSON.stringify({ error: "Missing url query param." }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      })
    }

    // Basic allowlist: only http(s)
    try {
      const u = new URL(src)
      if (!["http:", "https:"].includes(u.protocol)) {
        return new Response(JSON.stringify({ error: "Only http(s) URLs are allowed." }), {
          status: 400,
          headers: { "Content-Type": "application/json" },
        })
      }
    } catch {
      return new Response(JSON.stringify({ error: "Invalid url." }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      })
    }

    const upstream = await fetch(src, {
      method: "GET",
      // Avoid caching since source might be ephemeral
      cache: "no-store",
      headers: {
        // Some CDNs require a UA header
        "User-Agent": "meme-finder/1.0 (+https://v0.app)",
      },
    })

    if (!upstream.ok || !upstream.body) {
      const text = await upstream.text().catch(() => "")
      return new Response(
        JSON.stringify({
          error: "Failed to retrieve meme from source.",
          status: upstream.status,
          detail: text || null,
          source_url: src,
        }),
        { status: 502, headers: { "Content-Type": "application/json" } },
      )
    }

    // Derive content type and extension
    const contentType = upstream.headers.get("content-type") || "application/octet-stream"
    let ext = ""
    if (contentType.includes("gif")) ext = "gif"
    else if (contentType.includes("mp4")) ext = "mp4"
    else if (contentType.includes("webm")) ext = "webm"
    else if (contentType.includes("mpeg")) ext = "mpg"
    else if (contentType.includes("quicktime")) ext = "mov"

    // Try to pull an extension from the URL if content-type is generic
    if (!ext) {
      try {
        const path = new URL(src).pathname
        const maybe = path.split(".").pop() || ""
        if (maybe.length <= 5) {
          ext = maybe.replace(/[^a-z0-9]/gi, "").toLowerCase()
        }
      } catch {
        // ignore
      }
    }

    // Build a reasonably safe filename
    const safeTitle =
      titleParam
        .toString()
        .toLowerCase()
        .replace(/[^a-z0-9-_]+/gi, "-")
        .replace(/^-+|-+$/g, "") || "meme"

    const filename = `${safeTitle}${ext ? "." + ext : ""}`

    const headers = new Headers()
    headers.set("Content-Type", contentType)
    headers.set("Content-Disposition", `attachment; filename="${filename}"`)
    headers.set("Cache-Control", "no-store")

    return new Response(upstream.body, {
      status: 200,
      headers,
    })
  } catch (err: any) {
    return new Response(JSON.stringify({ error: "Unexpected server error", detail: err?.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}
