import { MemeFinder } from "@/components/meme-finder"

export default function Page() {
  return (
    <main className="container mx-auto px-4 py-10">
      <header className="mb-8">
        <h1 className="text-3xl md:text-4xl font-semibold text-pretty">Meme Finder</h1>
        <p className="mt-2 text-muted-foreground">Enter a quote and get a relevant meme video back.</p>
      </header>
      <MemeFinder />
    </main>
  )
}
