"use client"

import * as React from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Spinner } from "@/components/ui/spinner"

type MemeResponse = {
  title?: string
  meme_url?: string
  // allow unknown extra fields without breaking the UI
  [key: string]: unknown
}

export function MemeFinder() {
  const [quote, setQuote] = React.useState("")
  const [useTest, setUseTest] = React.useState(true) // default to test for easier local verification
  const [loading, setLoading] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)
  const [result, setResult] = React.useState<MemeResponse | null>(null)

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setResult(null)

    if (!quote.trim()) {
      setError("Please enter a quote.")
      return
    }

    setLoading(true)
    try {
      const res = await fetch("/api/find-meme", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ quote, mode: useTest ? "test" : "prod" }),
      })

      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        const message = [data?.error, data?.detail, data?.hint].filter(Boolean).join(" — ")
        throw new Error(message || "Failed to fetch meme. Try again.")
      }

      const data: MemeResponse = await res.json()
      setResult(data)
    } catch (err: any) {
      setError(err?.message || "Something went wrong. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  function resetForm() {
    setQuote("")
    setError(null)
    setResult(null)
  }

  const memeUrl = (result?.meme_url as string) || ""
  const copyUrl = React.useCallback(async () => {
    try {
      if (!memeUrl) return
      await navigator.clipboard.writeText(memeUrl)
    } catch (e) {
      // no-op; clipboard may be blocked
    }
  }, [memeUrl])

  return (
    <div className="w-full max-w-2xl mx-auto">
      <Card className="p-6">
        <form onSubmit={onSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <Label htmlFor="quote-input">Enter a quote</Label>
            <Input
              id="quote-input"
              value={quote}
              placeholder="e.g., when you realize it's Monday again"
              onChange={(e) => setQuote(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-2">
            <input
              id="use-test"
              type="checkbox"
              className="h-4 w-4"
              checked={useTest}
              onChange={(e) => setUseTest(e.target.checked)}
            />
            <Label htmlFor="use-test">Use test webhook</Label>
          </div>
          <p className="text-sm text-muted-foreground -mt-2">
            When using test mode, click "Execute workflow" in n8n, then submit immediately (works for one call).
          </p>

          <div className="flex items-center gap-3">
            <Button type="submit" disabled={loading}>
              {loading ? (
                <span className="inline-flex items-center gap-2">
                  <Spinner className="h-4 w-4" />
                  Finding...
                </span>
              ) : (
                "Find Meme"
              )}
            </Button>
            <Button type="button" variant="secondary" onClick={resetForm} disabled={loading}>
              Clear
            </Button>
          </div>

          {error && (
            <Alert variant="destructive" role="alert">
              <AlertTitle>Request failed</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {memeUrl && (
            <div className="mt-2">
              {result?.title ? (
                <h2 className="text-lg font-medium mb-2 text-pretty">{result.title as string}</h2>
              ) : null}
              <video key={memeUrl} src={memeUrl} controls className="w-full rounded-md" />
              <div className="mt-3 flex items-center gap-3 flex-wrap">
                <div className="text-sm break-all">
                  <span className="font-medium">URL:</span>{" "}
                  <a href={memeUrl} target="_blank" rel="noopener noreferrer" className="underline">
                    {memeUrl}
                  </a>
                </div>
                <Button type="button" variant="secondary" onClick={copyUrl}>
                  Copy URL
                </Button>
              </div>
            </div>
          )}
        </form>
      </Card>
    </div>
  )
}
